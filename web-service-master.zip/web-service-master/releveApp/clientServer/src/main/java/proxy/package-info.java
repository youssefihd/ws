@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://releveWS/")
package proxy;
